#ifndef __PRINCIPAIS__
#define __PRINCIPAIS__

#include "grafo.h"

int preencherGrafo(Grafo* g, FILE* fp);

#endif