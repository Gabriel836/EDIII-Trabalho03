#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grafo.h"


void listaPredadores(Grafo *grafo, char* presa);